
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateAIPosts = async () => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate 5 realistic social media posts for a feed. Include author name, a short status update, and mock engagement numbers.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              author: { type: Type.STRING },
              content: { type: Type.STRING },
              likes: { type: Type.NUMBER },
              comments: { type: Type.NUMBER },
              shares: { type: Type.NUMBER },
            },
            required: ["id", "author", "content", "likes", "comments", "shares"]
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Error generating posts:", error);
    return [];
  }
};

export const chatWithAI = async (history: { role: string, parts: { text: string }[] }[], message: string) => {
  try {
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: "You are a friendly friend on Facebook. Keep responses short, casual, and use emojis occasionally. You are responding in a chat interface."
      }
    });
    
    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Chat error:", error);
    return "Hey! My connection is a bit spotty, but I'm here!";
  }
};


import { User, Message, Post } from '../types';

const USERS_KEY = 'fblite_users';
const MESSAGES_KEY = 'fblite_messages';
const POSTS_KEY = 'fblite_posts';

export const db = {
  // User Management
  getUsers: (): User[] => JSON.parse(localStorage.getItem(USERS_KEY) || '[]'),
  saveUser: (user: User) => {
    const users = db.getUsers();
    users.push(user);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },
  findUser: (email: string) => db.getUsers().find(u => u.email === email),

  // Real-time Messages
  getMessages: (): Message[] => JSON.parse(localStorage.getItem(MESSAGES_KEY) || '[]'),
  sendMessage: (msg: Message) => {
    const messages = db.getMessages();
    messages.push(msg);
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(messages));
    // Trigger storage event manually for same-tab listeners if needed
    window.dispatchEvent(new Event('storage'));
  },

  // Posts
  getPosts: (): Post[] => JSON.parse(localStorage.getItem(POSTS_KEY) || '[]'),
  createPost: (post: Post) => {
    const posts = db.getPosts();
    posts.unshift(post);
    localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
    window.dispatchEvent(new Event('storage'));
  }
};

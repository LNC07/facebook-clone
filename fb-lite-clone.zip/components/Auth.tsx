
import React, { useState } from 'react';
import { AuthMode, User } from '../types';
import { db } from '../services/dbService';
import { NotificationToast } from './NotificationToast';

interface AuthProps {
  onLogin: (user: User) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    otp: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [notif, setNotif] = useState<{ title: string, body: string } | null>(null);

  const handleAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    if (mode === 'login') {
      const user = db.findUser(formData.email);
      if (user) {
        onLogin(user);
      } else {
        alert("Account not found. Please sign up.");
        setIsLoading(false);
      }
    } else if (mode === 'signup') {
      const code = Math.floor(10000 + Math.random() * 90000).toString();
      setGeneratedCode(code);
      setNotif({
        title: "Mail Notification",
        body: `Your Facebook Lite verification code is FB-${code}. Do not share it.`
      });
      setMode('verify');
      setIsLoading(false);
    } else if (mode === 'verify') {
      if (formData.otp === generatedCode) {
        const newUser: User = {
          id: `u_${Date.now()}`,
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.email,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${formData.firstName}${formData.lastName}`
        };
        db.saveUser(newUser);
        onLogin(newUser);
      } else {
        alert("Incorrect verification code.");
        setIsLoading(false);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#f0f2f5] flex flex-col items-center pt-8 px-4">
      {notif && <NotificationToast title={notif.title} body={notif.body} onClose={() => setNotif(null)} />}
      
      <h1 className="text-[#1877F2] text-4xl font-black mb-6">facebook</h1>
      
      <div className="w-full max-w-sm bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <form onSubmit={handleAction} className="space-y-3">
          {mode === 'login' && (
            <>
              <input 
                type="text" 
                placeholder="Mobile number or email" 
                className="w-full p-3 bg-[#f5f6f7] border border-gray-300 rounded text-sm focus:outline-none focus:border-blue-500"
                required
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
              <input 
                type="password" 
                placeholder="Password" 
                className="w-full p-3 bg-[#f5f6f7] border border-gray-300 rounded text-sm focus:outline-none focus:border-blue-500"
                required
              />
              <button 
                type="submit"
                className="w-full bg-[#1877F2] text-white font-bold py-2.5 rounded text-lg active:bg-blue-700"
              >
                {isLoading ? 'Loading...' : 'Log In'}
              </button>
              <div className="text-center pt-2">
                <a href="#" className="text-[#1877F2] text-sm">Forgot Password?</a>
              </div>
              <div className="flex items-center my-4">
                <div className="flex-1 border-t border-gray-200"></div>
                <span className="px-3 text-xs text-gray-400">or</span>
                <div className="flex-1 border-t border-gray-200"></div>
              </div>
              <div className="flex justify-center">
                <button 
                  type="button"
                  onClick={() => setMode('signup')}
                  className="bg-[#42b72a] text-white font-bold px-6 py-2 rounded text-sm active:bg-green-700"
                >
                  Create New Account
                </button>
              </div>
            </>
          )}

          {mode === 'signup' && (
            <>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="First Name" 
                  className="w-1/2 p-3 bg-[#f5f6f7] border border-gray-300 rounded text-sm focus:outline-none"
                  required
                  onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                />
                <input 
                  type="text" 
                  placeholder="Last Name" 
                  className="w-1/2 p-3 bg-[#f5f6f7] border border-gray-300 rounded text-sm focus:outline-none"
                  required
                  onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                />
              </div>
              <input 
                type="email" 
                placeholder="Email address" 
                className="w-full p-3 bg-[#f5f6f7] border border-gray-300 rounded text-sm focus:outline-none"
                required
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
              <input 
                type="password" 
                placeholder="New password" 
                className="w-full p-3 bg-[#f5f6f7] border border-gray-300 rounded text-sm focus:outline-none"
                required
              />
              <p className="text-[10px] text-gray-500 text-center px-2">
                By tapping Sign Up, you agree to our Terms and Data Policy.
              </p>
              <button 
                type="submit"
                className="w-full bg-[#42b72a] text-white font-bold py-2.5 rounded text-lg"
              >
                {isLoading ? 'Creating...' : 'Sign Up'}
              </button>
              <div className="text-center">
                <button type="button" onClick={() => setMode('login')} className="text-[#1877F2] text-sm">Back to Login</button>
              </div>
            </>
          )}

          {mode === 'verify' && (
            <>
              <h2 className="text-center font-bold text-gray-800 text-lg">Confirm Email</h2>
              <p className="text-xs text-gray-600 text-center mb-4">
                Enter the 5-digit code we sent to {formData.email}
              </p>
              <input 
                type="text" 
                placeholder="FB-XXXXX" 
                className="w-full p-4 bg-[#f5f6f7] border border-gray-300 rounded text-center text-2xl font-bold tracking-widest focus:outline-none"
                maxLength={5}
                required
                onChange={(e) => setFormData({...formData, otp: e.target.value})}
              />
              <button 
                type="submit"
                className="w-full bg-[#1877F2] text-white font-bold py-3 rounded text-lg mt-4"
              >
                {isLoading ? 'Verifying...' : 'Confirm'}
              </button>
            </>
          )}
        </form>
      </div>
    </div>
  );
};


import React from 'react';

interface IconProps {
  active?: boolean;
  className?: string;
}

export const HomeIcon: React.FC<IconProps> = ({ active, className }) => (
  <svg viewBox="0 0 24 24" fill={active ? "#1877F2" : "none"} stroke={active ? "none" : "#65676B"} strokeWidth="2" className={className}>
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <polyline points="9 22 9 12 15 12 15 22" />
  </svg>
);

export const FriendsIcon: React.FC<IconProps> = ({ active, className }) => (
  <svg viewBox="0 0 24 24" fill={active ? "#1877F2" : "none"} stroke={active ? "none" : "#65676B"} strokeWidth="2" className={className}>
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </svg>
);

export const MessageIcon: React.FC<IconProps> = ({ active, className }) => (
  <svg viewBox="0 0 24 24" fill={active ? "#1877F2" : "none"} stroke={active ? "none" : "#65676B"} strokeWidth="2" className={className}>
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
  </svg>
);

export const NotificationIcon: React.FC<IconProps> = ({ active, className }) => (
  <svg viewBox="0 0 24 24" fill={active ? "#1877F2" : "none"} stroke={active ? "none" : "#65676B"} strokeWidth="2" className={className}>
    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </svg>
);

export const VideoIcon: React.FC<IconProps> = ({ active, className }) => (
  <svg viewBox="0 0 24 24" fill={active ? "#1877F2" : "none"} stroke={active ? "none" : "#65676B"} strokeWidth="2" className={className}>
    <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18" />
    <line x1="7" y1="2" x2="7" y2="22" />
    <line x1="17" y1="2" x2="17" y2="22" />
    <line x1="2" y1="12" x2="22" y2="12" />
    <line x1="2" y1="7" x2="7" y2="7" />
    <line x1="2" y1="17" x2="7" y2="17" />
    <line x1="17" y1="17" x2="22" y2="17" />
    <line x1="17" y1="7" x2="22" y2="7" />
  </svg>
);

export const MenuIcon: React.FC<IconProps> = ({ active, className }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke={active ? "#1877F2" : "#65676B"} strokeWidth="2" className={className}>
    <line x1="3" y1="12" x2="21" y2="12" />
    <line x1="3" y1="6" x2="21" y2="6" />
    <line x1="3" y1="18" x2="21" y2="18" />
  </svg>
);

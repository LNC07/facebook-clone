
import React from 'react';
import { Story } from '../types';

const mockStories: Story[] = [
  { id: '1', user: 'Your Story', avatar: 'https://picsum.photos/seed/me/100/100', image: 'https://picsum.photos/seed/story1/200/300' },
  { id: '2', user: 'Sakib', avatar: 'https://picsum.photos/seed/sakib/100/100', image: 'https://picsum.photos/seed/story2/200/300' },
  { id: '3', user: 'Rahat', avatar: 'https://picsum.photos/seed/rahat/100/100', image: 'https://picsum.photos/seed/story3/200/300' },
  { id: '4', user: 'Anis', avatar: 'https://picsum.photos/seed/anis/100/100', image: 'https://picsum.photos/seed/story4/200/300' },
  { id: '5', user: 'Priya', avatar: 'https://picsum.photos/seed/priya/100/100', image: 'https://picsum.photos/seed/story5/200/300' },
];

export const Stories: React.FC = () => {
  return (
    <div className="bg-white mb-2 py-3 shadow-sm border-b border-gray-200">
      <div className="flex overflow-x-auto hide-scrollbar px-3 space-x-2">
        {/* Create Story */}
        <div className="relative min-w-[100px] h-40 rounded-xl overflow-hidden shadow-sm flex flex-col bg-gray-50 border border-gray-200 flex-shrink-0">
          <div className="h-2/3 bg-gray-200 overflow-hidden">
            <img src="https://picsum.photos/seed/myuser/100/150" alt="Me" className="w-full h-full object-cover" />
          </div>
          <div className="h-1/3 bg-white flex flex-col items-center justify-end pb-2 relative">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 bg-[#1877F2] rounded-full border-4 border-white flex items-center justify-center text-white">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" /></svg>
            </div>
            <span className="text-[10px] font-bold text-gray-800">Create story</span>
          </div>
        </div>

        {/* Other Stories */}
        {mockStories.slice(1).map(story => (
          <div key={story.id} className="relative min-w-[100px] h-40 rounded-xl overflow-hidden shadow-sm flex-shrink-0">
            <img src={story.image} alt={story.user} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black bg-opacity-10"></div>
            <div className="absolute top-2 left-2 w-8 h-8 rounded-full border-2 border-[#1877F2] p-0.5 overflow-hidden">
              <img src={story.avatar} alt={story.user} className="w-full h-full rounded-full object-cover" />
            </div>
            <span className="absolute bottom-2 left-2 text-white text-[10px] font-bold truncate max-w-[80px] drop-shadow-md">
              {story.user}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};


import React from 'react';
import { Post } from '../types';

interface PostItemProps {
  post: Post;
}

export const PostItem: React.FC<PostItemProps> = ({ post }) => {
  return (
    <div className="bg-white mb-2 shadow-sm border-y border-gray-200 sm:border-x sm:rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center p-3">
        <img 
          src={post.authorAvatar || `https://picsum.photos/seed/${post.author}/100/100`} 
          alt={post.author} 
          className="w-10 h-10 rounded-full mr-3 border border-gray-100"
        />
        <div className="flex-1">
          <h3 className="font-bold text-gray-900 text-sm">{post.author}</h3>
          <p className="text-gray-500 text-xs">{post.time} • 🌐</p>
        </div>
        <button className="text-gray-400 p-1">
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM18 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
        </button>
      </div>

      {/* Content */}
      <div className="px-3 pb-3">
        <p className="text-gray-800 text-sm whitespace-pre-wrap">{post.content}</p>
      </div>

      {/* Media */}
      {post.image && (
        <div className="w-full bg-gray-100">
          <img src={post.image} alt="Post content" className="w-full h-auto max-h-[500px] object-cover" />
        </div>
      )}

      {/* Stats */}
      <div className="px-3 py-2 flex items-center justify-between border-b border-gray-100 mx-3">
        <div className="flex items-center space-x-1">
          <div className="flex -space-x-1">
            <div className="bg-blue-500 rounded-full p-1 border border-white">
              <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M2 10.5a1.5 1.5 0 113 0v6a1.5 1.5 0 01-3 0v-6zM6 10.333v5.43a2 2 0 001.106 1.79l.05.025A4 4 0 008.943 18h5.416a2 2 0 001.962-1.608l1.2-6A2 2 0 0015.56 8H12V4a2 2 0 00-2-2 1 1 0 00-1 1v.667a4 4 0 01-.8 2.4L6.8 7.933a4 4 0 00-.8 2.4z" /></svg>
            </div>
            <div className="bg-red-500 rounded-full p-1 border border-white">
              <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" /></svg>
            </div>
          </div>
          <span className="text-xs text-gray-500">{post.likes}</span>
        </div>
        <div className="text-xs text-gray-500">
          <span>{post.comments} comments</span>
          <span className="mx-1">•</span>
          <span>{post.shares} shares</span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex text-gray-600 font-medium text-sm p-1">
        <button className="flex-1 flex items-center justify-center py-2 hover:bg-gray-100 rounded transition-colors">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 9l-2 2m0 0l-2-2m2 2V5m0 14h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          Like
        </button>
        <button className="flex-1 flex items-center justify-center py-2 hover:bg-gray-100 rounded transition-colors">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
          Comment
        </button>
        <button className="flex-1 flex items-center justify-center py-2 hover:bg-gray-100 rounded transition-colors">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
          Share
        </button>
      </div>
    </div>
  );
};
